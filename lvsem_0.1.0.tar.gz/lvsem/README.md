# lvsem

`lvsem` は、マルチセットPartial Least Squares（PLS）で構成した潜在変数
スコアを用いて、構造方程式モデルの経路を軽量かつ透明に推定するRパッケージ
です。

潜在変数スコアの作成、構造経路の回帰推定、直接・間接・総効果の分解、
ブートストラップ、測定モデルの要約に加えて、探索的媒介分析
PLS-EMA（Partial Least Squares Exploratory Mediation Analysis）を提供します。

## 特徴

- 複数の観測項目からマルチセットPLS潜在変数スコアを作成
- 潜在変数間の構造経路を通常最小二乗回帰で明示的に推定
- 直接効果、間接効果、総効果を計算
- ケース・ブートストラップにより経路の標準誤差を評価
- loading、Cronbachのα、composite reliability、AVEを要約
- PLS-EMAにより多数の媒介候補から媒介構造と整合する成分を探索

## インストール

```r
install.packages(
  "lvsem_0.1.0.tar.gz",
  repos = NULL,
  type = "source"
)
```

`lvsem` はマルチセットPLSの計算に
[`loadings`](https://cran.r-project.org/package=loadings) パッケージを使用します。

## 主要関数

| 関数 | 内容 |
|---|---|
| `make_lv_scores()` | 観測変数ブロックから潜在変数スコアを作成 |
| `estimate_paths()` | 潜在変数スコア間の構造経路を推定 |
| `bootstrap_paths()` | スコアと経路を再推定するケース・ブートストラップ |
| `effects_from_beta()` | 直接・間接・総効果を計算 |
| `measurement_summary()` | loading、信頼性、AVEを要約 |
| `pls_ema()` | Partial Least Squaresによる探索的媒介分析 |

## 基本的なPLS-SEM

```r
library(lvsem)

blocks <- list(
  X = c("x1", "x2", "x3"),
  M = c("m1", "m2", "m3"),
  Y = c("y1", "y2", "y3")
)

path_matrix <- rbind(
  X = c(X = 0, M = 0, Y = 0),
  M = c(X = 1, M = 0, Y = 0),
  Y = c(X = 1, M = 1, Y = 0)
)

scores <- make_lv_scores(dat, blocks, path_matrix)
paths <- estimate_paths(scores, path_matrix)
effects <- effects_from_beta(paths)
measurement <- measurement_summary(dat, blocks, scores)

boot <- bootstrap_paths(
  dat, blocks, path_matrix,
  br = 1000,
  seed = 123
)
```

## PLS-EMA

PLS-EMAは、説明変数ブロック \(X\)、媒介候補ブロック \(M\)、結果ブロック
\(Y\) から、媒介構造と整合する多変量成分を探索します。

\[
\operatorname{cov}(Xw,Mc)
+
\operatorname{cov}(Mc,Yu)
-
\operatorname{cov}(Xw,Yu)
\]

成分抽出には `loadings::multipls_geigen()` を使用します。抽出したスコアを
標準化し、経路 \(a\)、\(b\)、間接効果 \(ab\)、直接効果、総効果を計算します。
ブートストラップでは、各標本についてPLS成分から再推定します。

```r
data("satisfaction", package = "plspm")

names(satisfaction)[6:10] <- paste0("EXPE", 1:5)
names(satisfaction)[11:15] <- paste0("QUAL", 1:5)
names(satisfaction)[16:19] <- paste0("VAL", 1:4)
names(satisfaction)[20:23] <- paste0("SAT", 1:4)

fit <- pls_ema(
  data = satisfaction,
  x = paste0("EXPE", 1:5),
  mediators = c(paste0("QUAL", 1:5), paste0("VAL", 1:4)),
  y = paste0("SAT", 1:4),
  br = 1000,
  seed = 20260720
)

print(fit)
```

`fit$effects` は経路効果、`fit$mediators` は媒介候補のweightとloading、
`fit$covariance` は目的関数を構成する共分散、`fit$scores` は標準化スコアを
格納します。

## 解釈上の注意

PLS-EMAは探索的な成分抽出法です。結果ブロック \(Y\) の情報を使って媒介成分
を構成するため、通常の確認的PLS-SEM媒介分析や今井らの因果媒介分析とは
異なります。報告される \(ab\) はPLSスコア上の記述的な間接効果であり、
研究デザインと識別仮定なしに因果媒介効果とは解釈できません。

## ライセンス

MIT License
